//
//  TitleScreen.h
//  Get Me Outta Here!
//
//  Created by Kyle Kauck on 2015-03-23.
//  Copyright (c) 2015 Kyle Kauck. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>
@import GameKit;

@interface TitleScreen : SKScene

@end
