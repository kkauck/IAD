//
//  AppDelegate.h
//  Get Me Outta Here!
//
//  Created by Kyle Kauck on 2015-03-03.
//  Copyright (c) 2015 Kyle Kauck. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

